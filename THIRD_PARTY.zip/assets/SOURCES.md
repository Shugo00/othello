# 開発版で使う部品

### 石の音

| 素材・作者 | 録音の内容と使い方 |
|---|---|
| [Moving piece on a boardgame — zachrau](https://freesound.org/s/556387/) | マイクで収録した盤上の駒の音．異なる打音を切り出し，着手音3種類と反転音4種類に使った． |
| [Poker Chip Drop — Za-Games](https://freesound.org/s/540369/) | 卓に落ちた樹脂チップの音．個々の接触音だけを抜き出し，反転時の打音に小さく重ねた． |

両録音は[CC0 1.0](https://creativecommons.org/publicdomain/zero/1.0/)．作成用のMP3は[公開された原素材の控え](https://github.com/MatusSivak/Ancient-Terror/tree/main/source_assets/sounds/categories)から取得した．入力ファイルは `tools/audio_inputs/` に収録した．[加工スクリプト](../tools/make_stone_sounds.py)を開発環境で実行すると，低域の振動と高域の角を抑え，無音部分と余韻を整えたゲーム用WAVを再生成できる．

### フォントと共通部品

日本語フォントはNoto Sans CJK JP Regular 2.004．固定版，配布元，ハッシュは同梱の [font-manifest.json](font-manifest.json)，ライセンスは [OFL-NotoSansCJK.txt](OFL-NotoSansCJK.txt)．

Windowsの保存には共通部品1.0.0の `zatsu_common/atomicfile.py` を [src/atomicfile.py](../src/atomicfile.py) として使用する．導入元は `共通/reuse/components/v1.0.0`，原本のSHA-256は `2c5b942626f509b6e8b632a0934d6f97206954c5949095513ddf8a6b333088d5`．一時ファイルへの書込と置換を担当し，排他と履歴の復元はオセロ側で扱う．
